### Hexlet tests and linter status:
[![Actions Status](https://github.com/igor130384/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/igor130384/python-project-49/actions)
   https://asciinema.org/a/JVey889XsQP3DWSOwhf5ramOr
  https://asciinema.org/a/nyAUG3OLVdjGuxvBsuFSUlJNL
    https://asciinema.org/a/EIDoQo16UN5b7eUnptiRdBtr4
 https://asciinema.org/a/qIzKBB5gNvoFlPrFvHtV2qYk6 

 
<a href="https://codeclimate.com/github/igor130384/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/dc8da08af82f3a5a6d22/maintainability" /></a>

 Для сборки пакета используйте команду make build.
Чтобы установить пакет из операционной системы, используйте команду make package-install. Он должен быть запущен из корневого каталога проекта.
