### Hexlet tests and linter status:
[![Actions Status](https://github.com/igor130384/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/igor130384/python-project-49/actions)
   https://asciinema.org/a/JVey889XsQP3DWSOwhf5ramOr
  https://asciinema.org/a/nyAUG3OLVdjGuxvBsuFSUlJNL
    https://asciinema.org/a/EIDoQo16UN5b7eUnptiRdBtr4
 https://asciinema.org/a/qIzKBB5gNvoFlPrFvHtV2qYk6